import { writeFileSync } from "node:fs";
export default function(pi) {
  pi.on("session_start", (_event, ctx) => {
    writeFileSync("/tmp/history-cli-A16uXK/loaded.json", JSON.stringify(pi.getActiveTools()));
    ctx.shutdown();
  });
}