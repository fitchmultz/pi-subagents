
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { syncBuiltinESMExports } from "node:module";
const { default: agents } = await import(pathToFileURL(path.join(process.env.BENCH_REPO, "dist/agent/index.js")).href);
const emit = (value) => console.log(JSON.stringify(value));
let active = false;
let counters = {};
if (process.env.BENCH_PROFILE === "1") {
  for (const name of ["mkdirSync", "openSync", "writeFileSync", "fsyncSync", "renameSync", "readdirSync", "lstatSync", "statSync", "readSync", "readFileSync"]) {
    const original = fs[name];
    fs[name] = (...args) => {
      if (!active) return original(...args);
      const started = performance.now();
      try { return original(...args); }
      finally {
        const row = counters[name] ??= {calls: 0, ms: 0};
        row.calls++;
        row.ms += performance.now() - started;
      }
    };
  }
  syncBuiltinESMExports();
}
export default function (pi) {
  let started;
  let runs;
  pi.on("session_start", () => {
    counters = {};
    active = true;
    started = performance.now();
  });
  agents({...pi, registerTool(tool) {
    if (tool.name === "agent_runs") runs = tool;
    pi.registerTool(tool);
  }});
  pi.on("session_start", (_event, ctx) => {
    const ms = performance.now() - started;
    active = false;
    emit({type: "perf_attach", owner: ctx.sessionManager.getSessionId(), ms, counters});
  });
  pi.registerCommand("perf-list", {description: "Synthetic benchmark only", handler: async (_args, ctx) => {
    const before = performance.now();
    const result = await runs.execute("synthetic-first-list", {action: "list"}, undefined, undefined, ctx);
    emit({type: "perf_list", ms: performance.now() - before, details: result.details});
  }});
  pi.registerCommand("perf-quit", {description: "Exit this isolated probe", handler: async (_args, ctx) => {ctx.shutdown();}});
}
