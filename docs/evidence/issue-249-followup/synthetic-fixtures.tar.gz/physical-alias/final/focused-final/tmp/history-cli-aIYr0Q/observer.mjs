import { writeFileSync } from "node:fs";
export default function(pi) {
  pi.on("session_start", (_event, ctx) => {
    writeFileSync("/tmp/history-cli-aIYr0Q/loaded.json", JSON.stringify(pi.getActiveTools()));
    ctx.shutdown();
  });
}