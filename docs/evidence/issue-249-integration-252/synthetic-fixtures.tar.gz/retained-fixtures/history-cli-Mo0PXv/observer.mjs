import { writeFileSync } from "node:fs";
export default function(pi) {
  pi.on("session_start", (_event, ctx) => {
    writeFileSync("/workspace/issue-249-evidence/integration-252/retained-fixtures/history-cli-Mo0PXv/loaded.json", JSON.stringify(pi.getActiveTools()));
    ctx.shutdown();
  });
}